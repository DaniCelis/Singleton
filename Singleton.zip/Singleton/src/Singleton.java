
import java.util.Scanner;

public class Singleton {

    public static void main(String[] args) {

        int req = 0;
        int status;
        AtencionCajero s = AtencionCajero.atender();
        Scanner sc = new Scanner(System.in);

        while (req == 0 || req == 1) {

            System.out.println("Ingrese 1 si necesita una cajero y 0 si desocupa un cajero");
            req = sc.nextInt();

            if (req == 1) {
                for (int j = 0; j < 4; j++) {

                    status = s.cajasBanco[j].getEstado();
                    if (status == 1) {
                        System.out.println("Siga al cajero" + (j + 1));
                        if (status == 1) {
                            s.cajasBanco[j].setEstado(0);
                            j = 4;
                        }
                    } else if (status == 0) {
                        System.out.println("El cajero :" + (j + 1) + " esta ocupado espere");
                    }
                }

                System.out.println("Ocupando Cajero");
            } else {
                for (int j = 0; j < 4; j++) {
                    status = s.cajasBanco[j].getEstado();
                    if (status == 0) {
                        s.cajasBanco[j].setEstado(1);
                        System.out.println("Gracias por su transaccion. Hasta luego!");
                        System.out.println("Liberando Cajero" + (j+1));
                        j = 4;
                    }
                }
            }
        }
    }
}
